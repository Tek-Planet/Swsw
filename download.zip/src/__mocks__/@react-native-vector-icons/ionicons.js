import React from 'react';

const Ionicons = ({ name, size, color }) => {
  return <div data-testid="ionicons-mock" />; 
};

export default Ionicons;
